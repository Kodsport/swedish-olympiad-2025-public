#!/bin/bash

rustc -o karleksbrev main.rs
