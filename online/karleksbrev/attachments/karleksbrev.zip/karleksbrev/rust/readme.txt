Your code file has to be named karleksbrev.rs
When you submit it to Kattis, at the bottom of the screen there
is a box to change "Entry point:". Change this to main.rs
If you do not do this, you will simply get a compile error