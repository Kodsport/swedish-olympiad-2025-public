#!/bin/bash

./karleksbrev < sample.in
