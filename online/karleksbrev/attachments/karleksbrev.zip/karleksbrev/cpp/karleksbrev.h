#include <iostream>
#include <vector>

using namespace std;

string encode(string S);

string decode(string E);
