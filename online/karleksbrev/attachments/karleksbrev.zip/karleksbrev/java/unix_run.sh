#!/bin/bash

java Main < sample.in
